#!/bin/bash

# This script updates the contents of the workflows in workflow/demos 
# to every users in /home/virtual_home
# 
# first, it checks whether /home/virtual_home is mounted properlly.
# then it goes through all folder exepts:
#    - public_share_*
#    - xfce_config
#    - provenance_config
# and goto /home/virtual_home/KeplerData and put the new workflows to
# kepler.modules/coesra-tern-2.4.0/demos/conservation_planning and
# workflows/module/coesra-tern-2.4.0/demos/conservation_planning
# parameters: list of users not in the update list
EXCLUDE_USERS=( $@ )
EXCLUDE_DIRS=(public_share_data public_share_workflow xfce_config provenance_config)
NON_UPDATE_LIST=("${EXCLUDE_USERS[@]}" "${EXCLUDE_DIRS[@]}")
echo ${NON_UPDATE_LIST[@]}
is_mounted(){
    MOUNT_POINT='10.255.120.200:/tier2c3/Q0117/Q0117'
    mounted=`mount | grep ${MOUNT_POINT}`
    if [ ! "$mounted" ]; then
        return 1
    else
       return 0
    fi
}

if is_mounted; then
    echo "RDSI mounted. Proceed normally!!!"
else
    echo "RDSI not mounted. Exit!!!!"
    return 1
fi

home_folder="/home/virtual_home"
dirlist=$(find "$home_folder" -maxdepth 1 ! -path "$home_folder" -type d -print)
source="workflows/demos"
for dir in $dirlist; do
    _user=$(basename $dir)
    if [[ ! "${NON_UPDATE_LIST[@]}" =~ "$_user" ]]; then
        _kepler_modules=""
        _workflows=""
        if [ $_user == "KeplerData" ]; then
            _kepler_modules="$dir/kepler.modules/coesra-tern-2.4.0/demos"
            _workflows="$dir/workflows/module/coesra-tern-2.4.0/demos"
        else
            _kepler_modules="$dir/KeplerData/kepler.modules/coesra-tern-2.4.0/demos"
            _workflows="$dir/KeplerData/workflows/module/coesra-tern-2.4.0/demos"
        fi
        echo "sudo rm -rf $_kepler_modules" 
        sudo rm -rf $_kepler_modules
        echo "sudo cp -rf $source $_kepler_modules"
        sudo cp -rf $source $_kepler_modules
        echo "sudo rm -rf $_workflows"
        sudo rm -rf $_workflows
        echo "sudo cp -rf $source $_workflows"
        sudo cp -rf $source $_workflows
        if [ $_user != "KeplerData" ]; then
            echo "sudo rm -rf $dir/KeplerData/modules"
            sudo rm -rf $dir/KeplerData/modules
            echo "sudo chown $_user:$_user $_kepler_modules -R"
            sudo chown $_user:$_user $_kepler_modules -R
            echo "sudo chown $_user:$_user $_workflows -R"
            sudo chown $_user:$_user $_workflows -R
        fi
    fi
done

