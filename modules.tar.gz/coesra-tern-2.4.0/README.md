## CoESRA module ##

This repository consists of all the workflow deployed under the CoESRA workspace in Kepler environment.

The repo consist of scirpt to update the workflows to all users home folder