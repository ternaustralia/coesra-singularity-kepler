args <- commandArgs(TRUE)
library(sos)
working.directory <- paste(path.expand("~"), "/bin/R-MAP/", sep="")
source(paste(working.directory, "const_OzFlux.R", sep=""))

tower.name <- args[1]
tower.data <- "data_stats.csv"

rs.data <- paste(path.expand("~"), "/TERN/data/UTS_fpar_OzFlux.csv", sep="")
out.path <- paste(getwd(), "/", sep="")
out.data <- paste(out.path, tower.name, "_", sep="")
plot.type <- args[2]

lue_plot=function(tower.name, tower.data, rs.data, outp, type){
  mod.parms <-
    function(lm)
    {
      out <- c(lm$coefficients[1],
               lm$coefficients[2],
               length(lm$model$y),
               summary(lm)$coefficients[2,2],
               pf(summary(lm)$fstatistic[1], summary(lm)$fstatistic[2],
                  summary(lm)$fstatistic[3], lower.tail = FALSE),
               summary(lm)$r.squared)
      names(out) <- c("intercept","slope","n","slope.SE","p.value","r.squared")
      return(out)}
  ################################################################
  #  GPP
  delim = ","  # or is it "\t" ?
  dec = "."    # or is it "," ?
  data=read.csv(tower.data, header=T, sep=delim, dec=dec, stringsAsFactors=FALSE)
  dat.site=data.frame(cbind(year=as.numeric(data$year), month=as.numeric(data$month),GPP=as.numeric(data$GPP.mol), PPFD=as.numeric(data$gf.PPFD.mol), 
                            Tmean=as.numeric(data$Tmean),Tmin=as.numeric(data$Tmin),Tmax=as.numeric(data$Tmax),
                            Trange=as.numeric(data$Trange)))
  dat.sm=data.frame(cbind(year=dat.site$year, month=dat.site$month,GPP=dat.site$GPP, PPFD=dat.site$PPFD, 
                          Tmean=dat.site$Tmean,Tmin=dat.site$Tmin,Tmax=dat.site$Tmax, Trange=dat.site$Trange))
  ################################################################
  # FAPAR
  fpar=read.table(rs.data,
                  header=T, sep=",")
  fpar.site=subset(fpar, site==tower.name)
  print(fpar.site)
  fpar.mean=aggregate(. ~ year+month, data = fpar.site, FUN=mean)
  fpar.dat=merge(dat.sm, fpar.mean, by= intersect(names(dat.sm), names(fpar.mean)))
  dat=data.frame(cbind(year=dat.sm$year, month=dat.sm$month,GPP=dat.sm$GPP, PPFD=dat.sm$PPFD, Tmean=dat.sm$Tmean,Tmin=dat.sm$Tmin,Tmax=dat.sm$Tmax, Trange=dat.sm$Trange, fapar=fpar.dat$value))
  scale(dat)#standardize each column (we use it in the outdet function)
  outdet <- function(x) abs(scale(x)) >= 4 #create function that looks for values > +/- 2 sd from mean
  dat[!apply(sapply(dat, outdet), 1, any), ]#index with the function to remove those values
  ################################################################
  # GPP versus fAPAR*PPFD
  ################################################################  
  x=dat$fapar*dat$PPFD
  y=dat$GPP
  lmod= lm( I(y-0) ~ I(x-0) + 0)
  if (type=="jpeg" | type=="jpg"){
    jpeg(filename = paste(outp,"GPP_vs_Huete_fapar_by_I_monthly.jpg", sep="" ),
         width = 480, height = 600, units = "px", pointsize = 12,
         quality = 100,
         bg = "white") 
  }
  if (type=="pdf"){
    pdf(file=paste(outp,"GPP_vs_Huete_fapar_by_I_monthly.pdf", sep="" ), paper="a4r")
  }
  par(xaxs="i", yaxs="i") 
  main.text=paste(tower.name, ": GPP vs. fAPAR.PPFD ") # Slope=",round(coef(lmod)[[1]],4), " : RSE : ", round(coef(summary(lmod))[, "Std. Error"],4))
  with(dat, plot(x,y, xlim=c(0,max(x)), ylim=c(0, max(y, na.rm=T)),
                 xlab=expression(paste("fAPAR.PPFD (","mol m"^{-2}," month"^{-1},")",sep="")), 
                 ylab=expression(paste("GPP (mol m"^{-2}," month"^{-1},")",sep="")) , #main=main.text,
                 pch=c('j','f','m','a','M','J','u','A','s','o','n','d')[month]))
  # 
  mtext("j=jan f=feb m=mar a=apr M=may J=jun u=jul A=aug s=sep o=oct n=nov d=dec ", side=3, line=0)
  mtext(paste("LUE=",round(coef(lmod)[[1]],4), "RSE= ", round(coef(summary(lmod))[, "Std. Error"],4)), side=3, line=1)
  mtext(main.text, side=3, line = 3, font=2)
  abline(lmod, lwd=3)
  yhat <- as.data.frame(predict(lmod, interval = "confidence", level=0.95))
  lines(x[order(x)], yhat$lwr[order(x)], lty=3)
  lines(x[order(x)], yhat$upr[order(x)], lty=3)
  legend("topleft",c("slope","95% conf. int. "), lty=c(1,3), lwd=c(3,1))
  dev.off()
  # Return a list of LUE
  return(list(LUE=round(coef(lmod)[[1]],4)))
}

lue_plot(tower.name, tower.data,  rs.data,  outp=out.data, type=plot.type)
output_img <- paste(out.data,"GPP_vs_Huete_fapar_by_I_monthly.jpg", sep="" )
