#!/bin/bash


# author: hoang nguyen
# update ontologies and GUI
# 4 arguments: update both onyologies and GUI
# note that this script only update (by insert new config) into existing Kepler config
# it does not involve moving any associated file, this is done by ant


isdebug=true
ONTOLOGY=1
GUI=2


# author: hoang nguyen
# common functions


#
# print string
#
debugLog(){
	if [ $isdebug ]; then 
		echo "$@"
	fi
} 

#
# back up the file
# look for filename.${count}, if exists, increase count
# get the file name using
#
backup(){
	count=1
	newFileName=$1."old"$count
	while [ -e "$newFileName" ]
	do
		let "count += 1"
		newFileName=$1."old"$count
	done
	mv $1 $newFileName
	echo $newFileName
}


#
# function read and returns config contents
# must have 3 arguments: begin regex, end regex, and file name
#
readProcessNewConfig(){
	if [ $# -lt 3 ]; then
		exit 1
	fi 
	local beginRegex=$1
	local endRegex=$2
	local startComment="<\!\-\-"
	local endComment="\-\->"
	local fileName=$3
	local adding=false
	local newConfig=""
	while read line
	do
		# ignore empty line
		if [ -z "$line" ]; then
			continue
		fi
		if [[ $line =~ $beginRegex ]]; then
			adding=true
			continue
		fi
		if [[ $line =~ $endRegex ]]; then
			adding=false
			continue
		fi
		if [ $adding == true ]; then
			if [[ $line =~ $startComment ]]; then
				adding=false
			fi	
		fi
		if [ $adding == false ]; then
			if [[ $line =~ $endComment ]]; then
				adding=true
				continue
			fi
		fi
		if [ $adding == true ]; then
			newConfig="$newConfig$line"
		fi
	done < $fileName
	# return the new config
	echo $newConfig
}


#
# find in file $3(filename name) the string in $1(string literal), and if not found, append before $2 (refex)
# before doing anything, call backup to backup the file
#
findAndInsert(){
	if [ $# -lt 3 ]; then
		exit 1
	fi 
	local insertContents="$1"
	local endTagRegex="$2"
	local fileName="$3"
	# before reading the second command, do a grep
	local numOfAppearance=$(grep -c -F "$insertContents" "$fileName")
	debugLog "number of appearance: $numOfAppearance"
	if [ "$numOfAppearance" -gt 0 ]; then
		echo "No need to update, $insertContents is already in $fileName."
		exit 0
	fi
	# start processing
	# backup the old config
	local newConfigFile=$(backup "$fileName")
	# since keplerConfig is deleted, touch new one
	touch $fileName
	# read and write the existing config
	while read line
	do
		if [[ $line =~ $endTagRegex ]]; then
			echo -e "$insertContents\n$line"
		else
			echo "$line"	
		fi
	done < $newConfigFile > $fileName
}

#
# update onotlogies
#
updateConfig(){
	# check arguments
	if [ $# -lt 3 ]
	then
		echo "Insufficient arguments. Quit updateConfig."
		exit 1
	fi 
	# print them out
	configType=$1
	nimrodokConfig=$2
	keplerConfig=$3
	debugLog "Nimrod/OK config file: $nimrodokConfig"
	debugLog "Kepler config file: $keplerConfig"
	# process the first file
	beginString='^\-\-BEGIN\-\-'
	endString='^\-\-END\-\-'
	# newConfig=$(readProcessNewConfig "$beginString" "$endString" "$nimrodokConfig")
	newConfig=`readProcessNewConfig "$beginString" "$endString" "$nimrodokConfig"`
	debugLog "new config:" "$newConfig" 
	# process the second file
	if [ "$configType" -eq "$ONTOLOGY" ]
	then
		endConfigTag='<\/ontologies>'
	elif [ "$configType" -eq "$GUI" ]
	then
		endConfigTag='<\/config>'
	else
		echo "Invalid configType. Quit"
		exit 1
	fi
	# result=$(findAndInsert "$newConfig" "$endConfigTag" "$keplerConfig")
	message=`findAndInsert "$newConfig" "$endConfigTag" "$keplerConfig"`
	echo "$message"
}



# 
# check arguments
if [ $# -eq 2 ]; then
    echo "Updating ontologies"
    message=`updateConfig "$ONTOLOGY" $1 $2`
    echo "$message"
elif [ $# -eq 4 ]; then
    echo "Updating GUI"
    message=`updateConfig "$GUI" $3 $4`
    echo "$message"
else
    echo "Either 2 or 4 arguments. Quit now"
    exit 1
fi
