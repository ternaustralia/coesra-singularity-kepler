#!/usr/bin/Rscript

library(plyr)
library(lattice)

args <- commandArgs(TRUE)
detect_file <- args[1]
tmp <- strsplit(detect_file,'/')[[1]]
tmp2 <- tmp[length(tmp)]
detect_str <- substr(tmp2,1,nchar(tmp2)-4)
outdir <- './'
outpath <- paste0(outdir, detect_str, ".png")
if (any(ls() == "header") == FALSE) header= TRUE
if (any(ls() == "separator") == FALSE) separator = ""
if (any(ls() == "nrows") == FALSE) nrows = -1
if (any(ls() == "fill") == FALSE) fill = TRUE
df <- read.table(detect_file, sep=",", header=TRUE, nrows=nrows, fill=fill)
ReceiverName <- df[,5]
summary <- (ddply(df, c("TRANSMITTERID"), summarize, B=length(unique(ReceiverName))))
species <- summary[,1]
activities <- summary[,2]
outpath
png(outpath)
print(dotplot(activities~species, type="h"))
