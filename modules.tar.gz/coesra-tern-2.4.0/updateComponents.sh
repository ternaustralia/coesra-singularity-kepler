#!/bin/sh

# update the modules.txt file to in valude nimrodok
# arguments: componentname, filename
# format of componentname: nimrodk-2.4 (component-version)
if [ $# -lt 2 ]; then
	echo "Insufficient arguments. Quit updateComponents."
	exit 1
fi
componentName=$1
fileName=$2
numOfAppearance=$(grep -c -F "$componentName" "$fileName")
if [ $numOfAppearance -gt 0 ]; then
	echo "No need to update, $componentName is already in $fileName."
	exit 0
fi
# echo "$componentName.^" >> $fileName
echo "$componentName.^" | cat - $fileName > temp && mv temp $fileName
