args <- commandArgs(TRUE)
tower.name <- args[1]
out.dir <- paste(getwd(), "/", sep="")
working.directory <- paste(path.expand("~"), "/bin/R-MAP/", sep="")
data.path <- "data.csv"

source(paste(working.directory, "flux.gfpar.R", sep=""))
source(paste(working.directory, "flux.gpp.R", sep=""))
source(paste(working.directory, "flux.loadTower.R", sep=""))
source(paste(working.directory, "flux.formatTower.R", sep=""))
source(paste(working.directory, "flux.lsTowers.R", sep=""))
source(paste(working.directory, "flux.outfiles.R", sep=""))
source(paste(working.directory, "flux.parti.R", sep=""))
source(paste(working.directory, "flux.recthyp.R", sep=""))
source(paste(working.directory, "flux.rss.R", sep=""))
source(paste(working.directory, "sirad.corrEarthSunDist.R", sep=""))
source(paste(working.directory, "sirad.dayLength.R", sep=""))
source(paste(working.directory, "sirad.daylightTimeFactor.R", sep=""))
source(paste(working.directory, "sirad.dayOfYear.R", sep=""))
source(paste(working.directory, "sirad.degrees.R", sep=""))
source(paste(working.directory, "sirad.exd.R", sep=""))
source(paste(working.directory, "sirad.exh.R", sep=""))
source(paste(working.directory, "sirad.extrat.R", sep=""))
source(paste(working.directory, "sirad.radians.R", sep=""))
source(paste(working.directory, "sirad.solarDecl.R", sep=""))
source(paste(working.directory, "sirad.solarZenithAngle.R", sep=""))
source(paste(working.directory, "const_GlobalVariables.R", sep=""))
source(paste(working.directory, "const_OzFlux_PAR.R", sep=""))
source(paste(working.directory, "const_OzFlux.R", sep=""))

library(zoo)
library(xts)
library(ncdf)
library(sp)
library(raster)
library(minpack.lm)  

run.id <- "03-MAD"
out.file.path <- paste(out.dir,"out_",run.id, sep="")
#path.data.towers <- file.path(data.dir)i
assign(tower.name, flux.formatTower(tower.name, data.path)) 
flux.parti(tower.name,  out.file.path, run.id)

#tower_name2 <- tower.name
#tower_gpp <- paste(out.file.path,"/mm/", run.id, "_", tower.name,  "_stats.csv", sep="" )
